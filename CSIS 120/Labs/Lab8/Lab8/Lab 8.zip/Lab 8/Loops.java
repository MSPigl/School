import java.util.Scanner;

public class Loops
{
    public static void loop1(int n) {

    }

    public static void loop2(int n) {

    }

    public static void loop3(int n) {

    }

    public static void loop4(int n) {

    }    

    public static void loop5(int n) {

    }
    
    public static void loop6(int n) {

    }        

    public static void loop7(int n) {

    }     

    public static void loop8(int n) {

    }      

    public static void loop9(int n) {

    }    

    public static void loop10(int n) {

    }       

    public static void loop11(int n) {

    }

    public static void loop12(int n) {

    }
    
    public static void loop13(int n) {
      
    }

    public static void loop14(int n) {
  
    }    

    public static void loop15(int n) {
   
    }     

    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter value for n: ");
        int n = in.nextInt();
        
        System.out.println("\n\nLoop 1:");
        loop1(n);

        System.out.println("\n\nLoop 2:");
        loop2(n);

        System.out.println("\n\nLoop 3:");
        loop3(n);        

        System.out.println("\n\nLoop 4:");
        loop4(n);

        System.out.println("\n\nLoop 5:");
        loop5(n);        

        System.out.println("\n\nLoop 6:");
        loop6(n);        

        System.out.println("\n\nLoop 7:");
        loop7(n);        

        System.out.println("\n\nLoop 8:");
        loop8(n);        

        System.out.println("\n\nLoop 9:");
        loop9(n);        

        System.out.println("\n\nLoop 10:");
        loop10(n);        

        System.out.println("\n\nLoop 11:");
        loop11(n);        

        System.out.println("\n\nLoop 12:");
        loop12(n);        

        System.out.println("\n\nLoop 13:");
        loop13(n);        

        System.out.println("\n\nLoop 14:");
        loop14(n);        

        System.out.println("\n\nLoop 15:");
        loop15(n);           
    }
}
