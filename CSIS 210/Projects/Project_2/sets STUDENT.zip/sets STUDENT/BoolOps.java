import java.util.*;
import java.io.*;
/**
 * Code to unit test the LList implementation of ListInterface
 * Project 2
 * @updated
 */
public class BoolOps
{
         public void test()
    {
        int lineNum =0;
        System.out.println("Boolean set operations.");
        // define two lists, list1 and list2 of type String, here:
        
        
        // define and open file using scanner 
        String fileName = "testlist.txt";
        Scanner fromFile = null;
        
        // code a try-catch block here to open the file specified in the fileName variable
        
        
        
             
        // read in two lines of data into list1 and list2 
        // you may want to clear each list each time through
     
        while (fromFile.hasNextLine() ) {
            // list 1
                                    
            lineNum++;
            String nextLine = fromFile.nextLine();
            StringTokenizer st = new StringTokenizer(nextLine);
            System.out.println("Line number " + lineNum + " has " + st.countTokens() + " items in it");
            while (st.hasMoreTokens() ) {
                String item = st.nextToken();
                // System.out.println("Added to list 1:" + item);
               // carefully add item to list 1 here
            }
            // list 2
		
            lineNum++;
            nextLine = fromFile.nextLine();
            st = new StringTokenizer(nextLine);
            System.out.println("Line number " + lineNum + " has " + st.countTokens() + " items in it");
            while (st.hasMoreTokens() ) {
                String item = st.nextToken();
                // System.out.println("Added to list 2:" + item);
                // carefully add item to list 2 here
            }
            
            // call your methods here
            // union
            
            // intersection
            
            // difference
            
            // subset 
            
            // equivalent
            
            
                    }
        System.out.println( "Done!" );
    } // end test method
} // end class
